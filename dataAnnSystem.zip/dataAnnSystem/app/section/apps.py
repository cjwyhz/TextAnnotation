from django.apps import AppConfig


class SectionConfig(AppConfig):
    name = 'section'
    verbose_name = '章节信息'