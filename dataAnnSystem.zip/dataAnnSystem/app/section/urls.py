from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'section'
urlpatterns = [
    #path('index', views.get_home),
    re_path('getAllSections', views.getAllSections),
    re_path('insertSection', views.insertSection),
    re_path('addSection', views.addSection),
    re_path('getSectionInfo', views.getSectionInfo),
    re_path('editorSection', views.editorSection),
    re_path('accountGetSection', views.accountGetAllSection),


]