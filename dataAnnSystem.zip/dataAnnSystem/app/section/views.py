from django.shortcuts import render, redirect
from .models import SectionInfo
from textType.models import TextTypeInfo
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
from globalTool import pageTools
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数

def getAllSections(request):
    userID = request.session.get("userID", None)
    sections = SectionInfo.objects.filter(userID = userID, ifDel = 0)

    sectionsList = []
    for i in range(sections.count()):
        sectionsList.append(sections[i])

    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(sectionsList, PAGECOUNT)

    try:
        pageSections = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageSections = paginator.page(1)
    except EmptyPage:
        pageSections = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围
    pageSectionsList = pageSections.object_list

    sectionInfos = []
    signNames = []
    for i in range(len(pageSectionsList)):
        sectionInfos.append(pageSectionsList[i])
        signIDS = pageSectionsList[i].textTypes

        signName = ""
        if signIDS:
            siggnIds = str(signIDS).split(";")
            count = 0;
            for signID in siggnIds:
                if len(str(signID))>2:
                    count += 1
                    textType = TextTypeInfo.objects.get(id=signID)
                    signName = signName + "<li style='list-style:none;width:33.3%;float:left'>" + textType.name + "</li>"
        if len(signName) > 1:
            signName = "<ul>" + signName +"</ul>"
        signNames.append(signName)
    sectionInfoAndSignInfo = zip(sectionInfos,signNames)

    args = {"sections" : sectionInfoAndSignInfo,'paginator': paginator,
            "pageSections":pageSections,"pageRange":pageRange}
    return render(request, "section/userSections.html", args)

def insertSection(request):
    userID = request.session.get("userID", None)
    textTypes = TextTypeInfo.objects.filter(userID=userID)
    typesList = []
    for i in range(textTypes.count()):
        typesList.append(textTypes[i])
    return render(request, "section/addSection.html",{"textTypes":typesList})


def addSection(request):
    sectionName = request.POST.get('secName')
    sectionSign = request.POST.getlist('signs')

    sectionSignIDS = "";
    for signID in sectionSign:
        #print(signID)
        sectionSignIDS += (signID + ";")

    sectionSignIDS = sectionSignIDS[0:(int(len(sectionSignIDS)) - 1)]

    userID = request.session.get("userID", None)
    secNum = SectionInfo.objects.filter(secName = sectionName, userID = userID, ifDel = 0).count()
    msg = ""
    URL = ""
    if secNum < 1:
        secIndex = SectionInfo.objects.filter(userID=userID).count() + 1
        SectionInfo.objects.create(secIndex = secIndex, secName = sectionName, userID = userID,
                                   filesNum = 0,textTypes=sectionSignIDS, ifDel = 0)
        msg = "alert('添加成功');"
        URL = "global/transfer.html"
    else:
        msg = "alert('添加失败，库中已有此名称的章节');"
        URL = "global/transfer.html"
    return render(request, URL, {"msg":msg})

def getSectionInfo(request):
    secID = request.GET.get("secID")
    section = SectionInfo.objects.get(id = secID)

    signIDs = section.textTypes
    userID = request.session.get("userID", None)
    textTypes = TextTypeInfo.objects.filter(userID=userID)
    typesList = []
    for i in range(textTypes.count()):
        signID = str(textTypes[i].id)
        signName = str(textTypes[i].name)
        signInfo = ""
        if signID in signIDs:
            signInfo = "<input type='checkbox' name='signs' value='" + signID + "'" +\
                        "style='zoom:1.8;vertical-align: middle;' checked='checked'/><font size='3px'>" + \
                       signName + "</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
        else:
            signInfo = "<input type='checkbox' name='signs' value='" + signID + "'" +\
                       "style='zoom:1.8;vertical-align: middle;'/><font size='3px'>" + \
                       signName + "</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"

        typesList.append(signInfo)




    return render(request, "section/editorSection.html", {"section" : section,"signInfos":typesList})

def editorSection(request):
    sectionID = request.POST.get("secID");
    newName = request.POST.get("secName")
    targetSec = SectionInfo.objects.get(id=sectionID)
    oldName = targetSec.secName
    oldSign = str(targetSec.textTypes)
    msg = ""
    sectionSign = request.POST.getlist('signs')
    sectionSignIDS = "";
    for signID in sectionSign:
        # print(signID)
        sectionSignIDS += (signID + ";")

    sectionSignIDS = sectionSignIDS[0:(int(len(sectionSignIDS)) - 1)]


    URL = "global/transfer.html"
    if newName is oldName and oldSign is sectionSignIDS:
        msg  ="alert('修改失败，与原数据一致')"
    else:
        SectionInfo.objects.filter(id=sectionID).update(secName=newName,textTypes = sectionSignIDS)
        msg = "alert('修改成功')"

    return render(request, URL,{"msg":msg})

def accountGetAllSection(request):#account获取特定发布者的所有章节
    userID = request.GET.get("userID", None)
    sections = SectionInfo.objects.filter(userID=userID, ifDel=0)
    sectionInfos = []
    for i in range(sections.count()):
        sectionInfos.append(sections[i])

    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(sectionInfos, PAGECOUNT)

    try:
        pageSections = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageSections = paginator.page(1)
    except EmptyPage:
        pageSections = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围
    pageSectionsList = pageSections.object_list

    args = {"sections": pageSectionsList, "userID":userID,"pageSections":pageSections,
            "paginator":paginator,"pageRange":pageRange}

    return render(request, "section/accountShowUserSections.html", args)

# Create your views here.
