from .models import * 
import xadmin
from xadmin import views
from . import models

class SectionInfoAdmin:
	list_display = ['secIndex', 'secName']
	list_filter = ['secIndex', 'secName']
	fields = ['secIndex', 'secName']
	#search_fields=
	#list_per_page = 20
	
# class GlobalSettings(object):
# 	site_title = '章节信息'
# 	site_footer = '所有章节信息'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True
#
#
# xadmin.site.register(BaseInfo, BaseInfoAdmin)
#xadmin.site.register(views.CommAdminView, GlobalSettings)
#xadmin.site.register(views.BaseAdminView, BaseSetting)
