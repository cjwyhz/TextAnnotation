from django.db import models
import mongoengine

# Create your models here.

class SectionInfo(mongoengine.Document):
	secIndex = mongoengine.IntField(verbose_name='章节序号', default=-1)
	secName = mongoengine.StringField(verbose_name='章节名称', max_length=100, default='')
	userID = mongoengine.StringField(verbose_name='发布者信息', default="-1")
	textTypes = mongoengine.StringField(verbose_name='标签库', default="-1")
	filesNum = mongoengine.IntField(verbose_name='文件数', default=0)
	ifDel = mongoengine.IntField(verbose_name='是否删除', default=0)

	
	class Meta:
		verbose_name = '章节信息'
		verbose_name_plural = verbose_name
		db_table = 'sections'
	
	def __str__(self):
		return self.secName