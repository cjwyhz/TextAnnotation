from django.apps import AppConfig


class GlobalToolConfig(AppConfig):
    name = 'globalTool'
    verbose_name = '全局工具类'