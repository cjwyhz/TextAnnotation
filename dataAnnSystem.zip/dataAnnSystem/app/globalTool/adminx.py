from .models import * 
import xadmin
from xadmin import views
from . import models

# class BaseInfoAdmin:
# 	list_display = ['Name', 'Introduce']
# 	list_filter = ['Name', 'Introduce']
# 	fields = ['Name', 'Introduce']
# 	#search_fields=
# 	#list_per_page = 20
# 	style_fields = {'Introduce':'ueditor'}
	
class GlobalToolSettings(object):
	site_title = '全局工具'
	site_footer = '工具类'
	menu_style = 'accordion'
	
class BaseSetting(object):
	enable_themes = True
	use_bootswatch = True

	
# xadmin.site.register(BaseInfo, BaseInfoAdmin)
xadmin.site.register(views.CommAdminView, GlobalToolSettings)
xadmin.site.register(views.BaseAdminView, BaseSetting)
