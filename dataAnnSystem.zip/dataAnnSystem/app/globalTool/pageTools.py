from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
import datetime
import math
def getPageBtnRange(paginator,current_page,PAGEBTNCOUNT):
    pageNums = 0
    for index in paginator.page_range:
        pageNums = index
    groupIndex = math.ceil(current_page / PAGEBTNCOUNT)
    virtualStartIndex = (groupIndex - 1) * PAGEBTNCOUNT + 1
    virtualEndIndex = PAGEBTNCOUNT + virtualStartIndex - 1
    if virtualEndIndex > pageNums:
        virtualEndIndex = pageNums
        virtualStartIndex = pageNums - PAGEBTNCOUNT + 1
        if virtualStartIndex < 1:
            virtualStartIndex = 1;

    return range(virtualStartIndex,virtualEndIndex + 1)