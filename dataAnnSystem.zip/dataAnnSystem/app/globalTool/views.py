from django.shortcuts import render
def get_home(request):
    return render(request, "global/index.html")
# Create your views here.
