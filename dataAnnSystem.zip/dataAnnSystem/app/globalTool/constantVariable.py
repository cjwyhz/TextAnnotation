PAGECOUNT = 15
PAGEBTNCOUNT = 14  # 每页展示分页按钮个数
FILEDIR = "static\\myFiles\\files"