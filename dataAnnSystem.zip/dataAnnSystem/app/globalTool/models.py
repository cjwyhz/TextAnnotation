from django.db import models

# Create your models here.

class BaseInfo(models.Model):
	# Name = models.CharField(verbose_name='姓名', max_length=20, default='', blank=True)
	# Introduce = UEditorField(verbose_name='个人简介', max_length=2000, default='', width='70%', height='70%', blank=True)
	
	class Meta:
		verbose_name = '全局工具类'
		verbose_name_plural = verbose_name
	
	def __str__(self):
		return self.Name
	