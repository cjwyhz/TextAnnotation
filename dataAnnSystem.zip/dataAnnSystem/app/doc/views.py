from django.http import FileResponse
from django.shortcuts import render, redirect, HttpResponse
import datetime
from myFile.models import MyFileInfo
from .models import DocInfo
from textType.models import TextTypeInfo
from task.models import TaskInfo
import xlrd
from xlutils.copy import copy
from section.models import SectionInfo
import json
from xlrd import open_workbook
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
import os
import openpyxl
from globalTool import pageTools
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数
FILEDIR = constantVariable.FILEDIR#文档基础路径



from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数
FILEDIR = constantVariable.FILEDIR

class Mpaginator(Paginator):
    def __init__(self,page_tabs,object_list,per_page):
        Paginator.__init__(self,object_list,per_page)
        self.page_tabs = page_tabs

    def get_page_tabs(self):
        return self.page_tabs


def getDocByFileID(request):
    pageCount = 20;
    fileID = request.GET.get("fileID")
    taskID = request.GET.get("taskID")

    if not fileID:
        fileID = request.POST.get("fileID")

    if not taskID:
        taskID = request.POST.get("taskID")

    accountID = request.session.get("accountID", None)
    docs = DocInfo.objects.filter(fileID=fileID, accountID=accountID, ifDel=0)
    myFile = MyFileInfo.objects.get(id=fileID)
    task = TaskInfo.objects.get(id=taskID)
    if int(task.finishStatus) == 1:
        url = "/myFile/showExcelContext?fileID=" + fileID + "&url=myFile/fileContent.html"
        return render(request,"global/transferTitle.html",{"url":url,"title":str(myFile.fileName)})
    else:
        if docs.count() < 1:#该文档第一次被标记，将内容加入到数据库
            userID = myFile.userID
            fileName = myFile.fileName
            secID = myFile.secID
            filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName
            excel = xlrd.open_workbook(filePath)
            # 得到第一张表单
            sheet1 = excel.sheets()[0]
            # 找到有几列几列
            nrows = sheet1.nrows  # 行数
            ncols = sheet1.ncols  # 列数
            totalArray = []
            title = []
            # 标题
            for i in range(0, ncols):
                title.append(sheet1.cell(0, i).value);
            # 数据
            for rowindex in range(1, nrows):
                dic = {}
                for colindex in range(0, ncols):
                    s = sheet1.cell(rowindex, colindex).value
                    dic[title[colindex]] = s
                totalArray.append(dic);
                dic = json.dumps(dic)
                DocInfo.objects.create(textContext=dic, textType="", secID=myFile.secID,
                                       userID=myFile.userID, accountID=accountID, fileID=fileID, ifDel=0)
        secID = myFile.secID
        secTarget = SectionInfo.objects.get(id=secID)
        signIDS = secTarget.textTypes
        allDocs = DocInfo.objects.filter(fileID=fileID, accountID=accountID, ifDel=0)
        docsList = []
        for i in range(allDocs.count()):
            docsList.append(allDocs[i])
        try:
            current_page = int(request.POST.get('pageNum'))
        except Exception as e:
            current_page = 1
        paginator = Paginator(docsList, pageCount)

        try:
            pageDocs = paginator.page(current_page)
            #paginator.page_range
        except PageNotAnInteger:
            pageDocs = paginator.page(1)
        except EmptyPage:
            pageDocs = paginator.page(paginator.num_pages)

        pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)

        pageDocsList = pageDocs.object_list
        print("count = " + str(len(pageDocsList)))
        data = []
        dataSign = []
        title = []
        count = 0
        docIDS = ""

        for i in range(len(pageDocsList)):
            dictData = json.loads(pageDocsList[i].textContext)
            if count == 0:
                for key in dictData:
                    title.append(key)
            data.append(json.loads(pageDocsList[i].textContext))
            count += 1
            #为每一行绑定一组checkbox，name值为doc的id

            typesList = []
            if len(str(pageDocsList[i].textType)) < 2:   #未标记内容，绑定一组checkbox
                docIDS = docIDS + str(pageDocsList[i].id) + ";"
                if signIDS:
                    siggnIds = str(signIDS).split(";")
                    for signID in siggnIds:
                        if len(str(signID)) > 2:
                            count += 1
                            textType = TextTypeInfo.objects.get(id=signID)
                            signName = str(textType.name)
                            signInfo = "<input type='checkbox' name='" + str(pageDocsList[i].id) + "' value='" + signID + "'" + \
                                       "style='zoom:1.8;vertical-align: middle;'/><font size='3px'>" + signName + "</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                            typesList.append(signInfo)
            else:  #已标记内容，显示已标记的标签
                siggnIds = str(pageDocsList[i].textType).split(";")
                for signID in siggnIds:
                    if len(str(signID)) > 2:
                        count += 1
                        textType = TextTypeInfo.objects.get(id=signID)
                        signName = str(textType.name)
                        signInfo = signName + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                        typesList.append(signInfo)
            dataSign.append(typesList)

        docIDS = docIDS[0:(int(len(docIDS)) - 1)]
        dataAndSign = zip(data,dataSign)
        context = {"data":dataAndSign,"title":title,"docIDS":docIDS,"fileID":fileID,"taskID":taskID,"docs":pageDocs, 'paginator': paginator,"pageRange":pageRange}
        return render(request, "doc/workDoc.html",context)

def updateDocs(request):
    docIDS = request.POST.get("docIDS")
    taskID = request.POST.get("taskID")
    if docIDS:
        docIds = str(docIDS).split(";")#获取本页所有的docID，一个docID绑定一组checkbox
        for docID in docIds:
            if len(str(docID)) > 2:
                checkBoxName = str(docID)
                docID = checkBoxName
                docSignIDS = ""#doc对应的标记
                docSigns = request.POST.getlist(checkBoxName)#获取docID对应的checkbox
                for signID in docSigns:
                    docSignIDS = docSignIDS + signID + ";"

                if len(docSignIDS) > 1:
                    docSignIDS = docSignIDS[0:(int(len(docSignIDS)) - 1)]

                targetDoc = DocInfo.objects.get(id=docID)
                targetDoc.update(textType = docSignIDS)

    fileID = request.POST.get("fileID")
    accountID = request.session.get("accountID",None)
    unfinishedDocs = DocInfo.objects.filter(fileID=fileID, accountID=accountID, textType="", ifDel=0)
    if unfinishedDocs.count()>0:
        message = "alert('保存成功，请尽快完成剩余任务');"
    else:#完成本文件的任务
        message = "alert('您已完成本任务');"
        today = str(datetime.date.today())
        task = TaskInfo.objects.get(id=taskID)
        task.update(finishStatus=1,finishDate=today)
        file = MyFileInfo.objects.get(id=fileID)
        file.update(finishedStatus = 1,finishedDate = today)
        userID = file.userID
        secID = file.secID
        fileName = file.fileName
        filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName

        docContext = DocInfo.objects.filter(fileID=fileID, accountID=accountID, ifDel=0)
        signContexts = ['已标记的文本类型']
        deleteDocIds = []
        for index in range(docContext.count()):
            signContext = ""
            signIDS = str(docContext[index].textType)
            signIdsList = signIDS.split(";")
            for signID in signIdsList:
                if len(str(signID)) > 2:
                    textType = TextTypeInfo.objects.get(id=signID)
                    signName = str(textType.name)
                    signContext = signContext + signName + ";"
            if len(signContext) > 1:
                signContext = signContext[0:(int(len(signContext)) - 1)]
            signContexts.append(signContext)
            deleteDocIds.append(str(docContext[index].id))
            print("deleID = " + str(docContext[index].id))

        fileType = os.path.splitext(filePath)[1]
        print("fileType = " + fileType)
        print(str(fileType) == ".xls")
        print(str(fileType) is ".xls")

        if str(fileType) == ".xls":
            data = xlrd.open_workbook(filePath, formatting_info=True)
            excel = copy(wb=data)  # 完成xlrd对象向xlwt对象转换
            excel_table = excel.get_sheet(0)  # 获得要操作的页
            table = data.sheets()[0]
            nrows = table.nrows  # 获得行数
            ncols = table.ncols  # 获得列数
            values = signContexts  # 需要写入的值
            rowTmp = 0;
            for value in values:
                excel_table.write(rowTmp, ncols, value)  # 因为单元格从0开始算，所以row不需要加一
                rowTmp = rowTmp + 1
            if os.path.exists(filePath):
                os.remove(filePath)
            excel.save(filePath)
        else:
            data = openpyxl.load_workbook(filePath)
            print(data.get_named_ranges())  # 输出工作页索引范围
            print(data.get_sheet_names())  # 输出所有工作页的名称
            # 取第一张表
            sheetnames = data.get_sheet_names()
            table = data.get_sheet_by_name(sheetnames[0])
            table = data.active
            print(table.title)  # 输出表名
            nrows = table.max_row  # 获得行数
            ncolumns = table.max_column  # 获得行数
            values = signContexts
            rowTmp = 1;
            for value in values:
                table.cell(rowTmp, ncolumns + 1).value = value
                rowTmp += 1
            if os.path.exists(filePath):
                os.remove(filePath)
            data.save(filePath)
        #修改原文件

        for delDocID in deleteDocIds:
            print("docID = " + str(delDocID))
            docTmp = DocInfo.objects.get(id=delDocID)
            docTmp.delete()#删除原始doc
    tasks = TaskInfo.objects.filter(accountID=accountID, finishStatus=0)#重新获取待完成任务数
    del request.session["taskNumber"]
    request.session['taskNumber'] = str(tasks.count())
    return render(request,"global/transfer.html",{"msg":message})






