from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'doc'
urlpatterns = [
    #path('index', views.get_home),
    re_path('getDocByFileID', views.getDocByFileID),
    re_path('updateDocs', views.updateDocs),
]