from django.db import models
import mongoengine

# Create your models here.

class DocInfo(mongoengine.Document):
	textContext = mongoengine.StringField(verbose_name='文本内容', default='')
	textType = mongoengine.StringField(verbose_name='文本类型', max_length=100, default='')
	secID = mongoengine.StringField(verbose_name='章节编号', default="")
	userID = mongoengine.StringField(verbose_name='所属发布人', default="")
	accountID = mongoengine.StringField(verbose_name='任务完成者', default="")
	fileID = mongoengine.StringField(verbose_name='所属文件', default="")
	ifDel = mongoengine.IntField(verbose_name='是否删除', default=0)

	class Meta:
		verbose_name = '文档信息'
		verbose_name_plural = verbose_name
		db_table = 'docs'

	
	def __str__(self):
		return self.textContext