from django.apps import AppConfig


class DocConfig(AppConfig):
    name = 'doc'
    verbose_name = '文档内容'