from .models import * 
import xadmin
from xadmin import views
from . import models

class BaseInfoAdmin:
	list_display = ['textContext', 'textType']
	list_filter = ['textContext', 'textType']
	fields = ['textContext', 'textType']
	#search_fields=
	#list_per_page = 20
	#style_fields = {'textContext':'ueditor'}
	
# class GlobalSettings(object):
# 	site_title = '文档内容'
# 	site_footer = '文档'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True

	
#xadmin.site.register(BaseInfo, BaseInfoAdmin)
#xadmin.site.register(views.CommAdminView, GlobalSettings)
#xadmin.site.register(views.BaseAdminView, BaseSetting)
