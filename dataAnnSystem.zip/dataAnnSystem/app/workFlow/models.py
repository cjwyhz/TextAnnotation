from django.db import models
import mongoengine

# Create your models here.

class WorkFlowInfo(mongoengine.Document):
	fileID = mongoengine.StringField(verbose_name='文件信息', default='')
	accountID = mongoengine.StringField(verbose_name='申请者信息', default=' ')
	secID = mongoengine.StringField(verbose_name='章节信息', default='')
	examID = mongoengine.StringField(verbose_name='预审批者信息', default='')
	applyDate = mongoengine.StringField(verbose_name='申请时间', max_length=20, default=" ")
	result = mongoengine.IntField(verbose_name='审批结果', default=-1)
	examDate = mongoengine.StringField(verbose_name='审批时间', max_length=20, default=" ")
	status = mongoengine.IntField(verbose_name='审批状态', default=0)
	
	class Meta:
		verbose_name = '审批工作流'
		verbose_name_plural = verbose_name
		db_table = 'workFlows'

	
	def __str__(self):
		return self.accountID