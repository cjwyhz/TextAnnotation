from django.shortcuts import render,redirect
from .models import WorkFlowInfo
from myFile.models import MyFileInfo
from section.models import SectionInfo
from account.models import AccountInfo
from task.models import TaskInfo
from user.models import UserInfo
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
import datetime
import math
from globalTool import pageTools
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数

def applyFile(request):
    fileID = request.GET.get("fileID")
    accountID = request.session.get("accountID", None)
    myFile = MyFileInfo.objects.get(id=fileID)
    today = datetime.date.today()
    secID = myFile.secID
    userID = myFile.userID
    WorkFlowInfo.objects.create(fileID = fileID, accountID = accountID,
                                secID = myFile.secID, examID = myFile.userID,
                                applyDate = str(today), result = -1, examDate = '-1', status = 0)
    msg = "alert('申请成功');"
    return redirect("/myFile/accountGetFilesBySection?userID=" + userID + "&secID=" + secID + "&msg=" + msg)


def getAllExamApply(request):#获取待审批任务
    userID = request.session.get("userID", None)
    workFlows = WorkFlowInfo.objects.filter(examID = userID, status = 0)#查找未审批工作流

    wfsList = []
    for i in range(workFlows.count()):
        wfsList.append(workFlows[i])
    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(wfsList, PAGECOUNT)

    try:
        pageWorkFlows = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageWorkFlows = paginator.page(1)
    except EmptyPage:
        pageWorkFlows = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator,current_page,PAGEBTNCOUNT)#获取按钮显示范围
    workFlowsList = pageWorkFlows.object_list
    msg = request.GET.get("msg")

    args = []
    workFlowsInfo = []
    for i in range(len(workFlowsList)):
        arg = []
        workFlowsInfo.append(workFlowsList[i])
        fileID = workFlowsList[i].fileID
        accountID = workFlowsList[i].accountID
        sectionID = workFlowsList[i].secID

        fileInfo = MyFileInfo.objects.get(id = fileID)
        accountInfo = AccountInfo.objects.get(id = accountID)
        sectionInfo = SectionInfo.objects.get(id = sectionID)

        arg.append(sectionInfo.secName)
        arg.append(fileInfo.fileName)
        arg.append(accountInfo.name)

        args.append(arg)

    workFlowAndOtherInfo = zip(workFlowsInfo, args)

    context = {}
    if msg:
        context = {"workFlowAndOtherInfo": workFlowAndOtherInfo, "msg":msg,'paginator': paginator,
                   "pageWorkFlows":pageWorkFlows,"pageRange":pageRange}
    else:
        context = {"workFlowAndOtherInfo": workFlowAndOtherInfo,'paginator': paginator,
                   "pageWorkFlows":pageWorkFlows,"pageRange":pageRange}
    return render(request, "workFlow/userWorkFlows.html", context)

def examApply(request):#审批任务
    workFlowID = request.POST.get("workFlowID")
    result = int(request.POST.get("result"))
    wfIDs = request.POST.getlist("wfID")
    if workFlowID:
        wfIDs.append(workFlowID)
    for wfID in wfIDs:
        workFlow = WorkFlowInfo.objects.get(id = wfID)
        today = str(datetime.date.today())
        WorkFlowInfo.objects.get(id = wfID).update(result = result, examDate = today, status = 1)
        if result == 1:
            TaskInfo.objects.create(fileID = workFlow.fileID, applyDate = today, accountID = workFlow.accountID,
                                    userID = workFlow.examID, finishStatus = 0, finishDate = "-", ifDel = 0)
            MyFileInfo.objects.get(id = workFlow.fileID).update(taskAccountID = workFlow.accountID)

    del request.session["taskNum"]
    userID = request.session.get("userID",None)
    workFlows = WorkFlowInfo.objects.filter(examID=userID, status=0)  # 查找未审批工作流
    request.session['taskNum'] = workFlows.count()
    msg = "alert('审批完成');"
    return redirect("/workFlow/getAllExamApply?msg=" + msg)

def accountGetApplyRecord(request):#学生获取申请记录
    accountID = request.session.get("accountID", None)
    workFlows = WorkFlowInfo.objects.filter(accountID = accountID).order_by('-applyDate')
    wfsList = []
    for i in range(workFlows.count()):
        wfsList.append(workFlows[i])
    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(wfsList, PAGECOUNT)

    try:
        pageWorkFlows = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageWorkFlows = paginator.page(1)
    except EmptyPage:
        pageWorkFlows = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)

    workFlowsList = pageWorkFlows.object_list
    args = []
    workFlowsInfo = []
    for i in range(len(workFlowsList)):
        arg = []
        workFlowsInfo.append(workFlowsList[i])
        fileID = workFlowsList[i].fileID
        userID = workFlowsList[i].examID
        sectionID = workFlowsList[i].secID

        fileInfo = MyFileInfo.objects.get(id=fileID)
        userInfo = UserInfo.objects.get(id=userID)
        sectionInfo = SectionInfo.objects.get(id=sectionID)

        arg.append(userInfo.name)
        arg.append(sectionInfo.secName)
        arg.append(fileInfo.fileName)

        args.append(arg)
    workFlowAndOtherInfo = zip(workFlowsInfo, args)
    context = {"workFlowAndOtherInfo":workFlowAndOtherInfo,'paginator': paginator,
               "pageWorkFlows":pageWorkFlows,"pageRange":pageRange}
    return render(request, "workFlow/accountApplyRecord.html", context)

def getApplyRecordUsers(request):#学生获得申请记录用户
    print("-------------------------------------")
    accountID = request.session.get("accountID", None)
    #workFlows = WorkFlowInfo.objects.filter(accountID = accountID).values("examID").distinct().group_by("examID")
    users = WorkFlowInfo.objects.filter(accountID=accountID).fields("examID").distinct("examID")
    usersList = []
    for userID in users:
        user = UserInfo.objects.get(id=str(userID))
        usersList.append(user)
    return render(request,"user/allUsers.html",{"users":usersList})

def getApplyUserSection(request):
    userID = request.GET.get("userID")
    accountID = request.session.get("accountID",None)
    sectionIds = WorkFlowInfo.objects.filter(accountID=accountID,examID=userID,).fields("secID").distinct("secID")
    sectionsList = []
    for secID in sectionIds:
        section = SectionInfo.objects.get(id = secID)
        sectionsList.append(section)
    return render(request,"section/accountApplySections.html",{"sections":sectionsList,"userID":userID})

def getFinishedExamApply(request):#获取已完成审批的记录
    userID = request.session.get("userID", None)
    workFlows = WorkFlowInfo.objects.filter(examID = userID, status = 1).order_by("-examDate")#查找已审批工作流

    wfsList = []
    for i in range(workFlows.count()):
        wfsList.append(workFlows[i])
    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(wfsList, PAGECOUNT)

    try:
        pageWorkFlows = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageWorkFlows = paginator.page(1)
    except EmptyPage:
        pageWorkFlows = paginator.page(paginator.num_pages)
    workFlowsList = pageWorkFlows.object_list


    pageRange = pageTools.getPageBtnRange(paginator,current_page,PAGEBTNCOUNT)

    args = []
    workFlowsInfo = []
    for i in range(len(workFlowsList)):
        arg = []
        workFlowsInfo.append(workFlowsList[i])
        fileID = workFlowsList[i].fileID
        accountID = workFlowsList[i].accountID
        sectionID = workFlowsList[i].secID

        fileInfo = MyFileInfo.objects.get(id = fileID)
        accountInfo = AccountInfo.objects.get(id = accountID)
        sectionInfo = SectionInfo.objects.get(id = sectionID)

        arg.append(sectionInfo.secName)
        arg.append(fileInfo.fileName)
        arg.append(accountInfo.name)

        args.append(arg)

    workFlowAndOtherInfo = zip(workFlowsInfo, args)

    context = {"workFlowAndOtherInfo": workFlowAndOtherInfo,'paginator': paginator,"pageWorkFlows":pageWorkFlows,"pageRange":pageRange}
    return render(request, "workFlow/userFinishedWorkFlows.html", context)







# Create your views here.
