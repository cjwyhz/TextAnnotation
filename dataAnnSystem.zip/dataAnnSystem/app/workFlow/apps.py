from django.apps import AppConfig


class WorkFlowConfig(AppConfig):
    name = 'workFlow'
    verbose_name = '工作流'