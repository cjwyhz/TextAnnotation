from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'workFlow'
urlpatterns = [
    #path('index', views.get_home),
    re_path('accountApplyFile', views.applyFile),
    re_path('getAllExamApply', views.getAllExamApply),
    re_path('examApply', views.examApply),
    re_path('accountGetApplyRecord', views.accountGetApplyRecord),
    re_path('userGetFinishedExam', views.getFinishedExamApply),
    re_path('getApplyRecordUsers', views.getApplyRecordUsers),
    re_path('getApplyUserSection', views.getApplyUserSection),
]