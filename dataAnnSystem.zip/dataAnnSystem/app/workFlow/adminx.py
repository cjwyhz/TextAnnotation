from .models import * 
import xadmin
from xadmin import views
from . import models

class WorkFlowInfoAdmin:
	list_display = ['accountID']
	list_filter = ['accountID']
	fields = ['accountID']
	#search_fields=
	#list_per_page = 20
	
# class GlobalSettings(object):
# 	site_title = '审批工作流'
# 	site_footer = '审批工作流'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True

	
#xadmin.site.register(BaseInfo, BaseInfoAdmin)
#xadmin.site.register(views.CommAdminView, GlobalSettings)
#xadmin.site.register(views.BaseAdminView, BaseSetting)
