import mongoengine
from bson.objectid import ObjectId

# Create your models here.

class AccountInfo(mongoengine.Document):
	name = mongoengine.StringField(verbose_name='姓名', max_length=20, default='')
	password = mongoengine.StringField(verbose_name='密码', max_length=20, default='')
	registerDate = mongoengine.StringField(verbose_name='注册时间', max_length=20, default='')
	phone = mongoengine.StringField(verbose_name='手机号', max_length=20, default='')
	mail = mongoengine.StringField(verbose_name='邮箱', max_length=20, default='')
	ifDel = mongoengine.IntField(verbose_name='是否删除', default=0)
	#Introduce = UEditorField(verbose_name='个人简介', max_length=2000, default='', width='70%', height='70%', blank=True)
	
	class Meta:
		verbose_name = '客户基本信息'
		verbose_name_plural = verbose_name
		db_table = 'accounts'
	
	def __str__(self):
		return "'" + str(self.id) + "':'" + self.name +"'"
	