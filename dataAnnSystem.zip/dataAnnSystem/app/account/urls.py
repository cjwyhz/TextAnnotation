from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'account'
urlpatterns = [
    path('index', views.get_home),
    re_path('accountRegister', views.accountRegister),
    re_path('accountLogin', views.accountLogin),
    re_path('accountInfo', views.accountInfo),
    re_path('welcome', views.welcome),
    re_path('editorAccountInfo', views.editorAccountInfo),
    re_path('accountLogOut', views.accountLogOut),
]