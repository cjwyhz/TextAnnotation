from django.shortcuts import render, redirect
from .models import AccountInfo
import datetime
import mongoengine
import invitation
from bson.objectid import ObjectId
from task.models import TaskInfo
import re
def get_home(request):
    return render(request, "account/accountLogin.html")

def accountRegister(request):
    userName = request.POST.get('userName')
    pwd = request.POST.get('password')

    countNum = AccountInfo.objects.filter(name=userName).count()
    msg = ""

    if countNum <= 0:
        phoneNum = request.POST.get('phone')
        Email = request.POST.get('mail')
        today = datetime.date.today()
        AccountInfo.objects.create(name = userName, password = pwd, registerDate = str(today), phone = str(phoneNum), mail = Email, ifDel = 0)
        msg = "注册成功,请登录"
    else:
        msg = "注册失败,用户名已占用"

    msg = "alert('" + msg +"');"
    return render(request, "account/accountLogin.html", {"msg":msg})

def accountLogin(request):
    userName = request.POST.get('userName')
    pwd = request.POST.get('password')
    print(userName,pwd)
    accounts = AccountInfo.objects.filter(name=userName, password=pwd)
    countNum = accounts.count()
    request
    msg = "";
    URL = ""
    if countNum == 1:
        msg = "登录成功"
        print("登录成功")
        URL = "account/index.html"
        print(str(accounts[0]))
        string = str(accounts[0])
        print("string = ",string)
        accountID = str(accounts[0].id)
        accountName = str(accounts[0].name)

        request.session.flush()
        tasks = TaskInfo.objects.filter(accountID=accountID,finishStatus=0)
        request.session['accountID'] = accountID
        request.session['accountName'] = accountName
        request.session['taskNumber'] = tasks.count()
    else:
        msg = "登录失败"
        print("登录失败")
        URL = "account/accountLogin.html"
    loginMessage = "alert('" + msg +"');"
    #data = str(all).decode("unicode-escape")
    return render(request, URL, {"msg": loginMessage})
    #return redirect('polls:home')

def accountInfo(request):
    accountID = request.session.get("accountID", None)
    account = AccountInfo.objects.get(id = accountID)
    if account:
        URL = "account/editorInfo.html"
        return render(request, URL, {"account": account})
    else:
        URL = "account/accountLogin.html"
        return render(request, URL, {"msg":"alert('请重新登录')"})

def welcome(request):
    accountID = request.session.get("accountID", None)
    account = AccountInfo.objects.get(id = accountID)
    if account:
        URL = "account/accountInfo.html"
        return render(request, URL, {"account": account})
    else:
        URL = "account/accountLogin.html"
        return render(request, URL, {"msg":"alert('请重新登录')"})

def editorAccountInfo(request):
    accountID = request.session.get("accountID", None)
    userName = request.POST.get('userName')
    pwd = request.POST.get('password')
    phoneNum = request.POST.get('phone')
    Email = request.POST.get('mail')
    AccountInfo.objects.filter(id = accountID).update(name = userName, password = pwd, phone = str(phoneNum), mail = Email, ifDel = 0)
    msg = "alert('修改成功，请重新登录')"
    URL = "account/accountLogin.html"
    request.session.flush()
    return render(request, URL, {"msg": msg})
    #return redirect("/account/index")

def accountLogOut(request):
    URL = "account/accountLogin.html"
    request.session.flush()
    msg = "alert('退出成功,感谢使用')"
    return render(request, URL, {"msg": msg})

# Create your views here.

# Users.objects.create(username="456", password="789")
#
# # 删除
# Users.objects.filter(username="123").first().delete()
#
# # 修改
# Users.objects.filter(username="aaa").first().update(password="123")

# # 查找
# # 查找所有
# Users.objects.all()
# # 筛选内容
# Users.objects.filter(username="aaa")
# # 获得第一个
# Users.objects.filter(username="aaa").first()
# # 获得数量
# Users.objects.filter(username="aaa").count()

