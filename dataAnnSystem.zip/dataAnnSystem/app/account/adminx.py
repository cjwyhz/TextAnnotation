from .models import *
import xadmin
from xadmin import views
from . import models

class AccountInfoAdmin:
	list_display = ['name', 'phone']
	list_filter = ['name', 'phone']
	fields = ['name', 'phone']
	#search_fields=
	#list_per_page = 20

# class GlobalSettings(object):
# 	site_title = '客户信息'
# 	site_footer = '客户基本信息'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True


#xadmin.site.register(AccountInfo, AccountInfoAdmin)
# xadmin.site.register(views.CommAdminView, GlobalSettings)
# xadmin.site.register(views.BaseAdminView, BaseSetting)
