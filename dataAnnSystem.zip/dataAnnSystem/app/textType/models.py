from django.db import models
import mongoengine

# Create your models here.

class TextTypeInfo(mongoengine.Document):
	name = mongoengine.StringField(verbose_name='类型名称', max_length=20, default='')
	userID = mongoengine.StringField(verbose_name='所属发布者', default='')
	ifDel = mongoengine.IntField(verbose_name='是否删除', default='')
	
	class Meta:
		verbose_name = '人物基本信息'
		verbose_name_plural = verbose_name
		db_table = 'textType'
	
	def __str__(self):
		return self.name