from .models import * 
import xadmin
from xadmin import views
from . import models

class TextTypeInfoAdmin:
	list_display = ['name']
	list_filter = ['name']
	fields = ['name']
	#search_fields=
	#list_per_page = 20
	
# class GlobalSettings(object):
# 	site_title = '文本备选类型'
# 	site_footer = '文本备选类型'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True

	
#xadmin.site.register(TextTypeInfo, TextTypeInfoAdmin)
#xadmin.site.register(views.CommAdminView, GlobalSettings)
#xadmin.site.register(views.BaseAdminView, BaseSetting)
