from django.apps import AppConfig


class TextTypeConfig(AppConfig):
    name = 'textType'
    verbose_name = '文本类型'