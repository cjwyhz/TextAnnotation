from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'textType'
urlpatterns = [
    re_path('userGetTextTypes', views.getUserTextType),
    re_path('userInsertTextType', views.userInsertTextType),
    re_path('addTextType', views.addTextType),
    re_path('editorTextType', views.editorTextType),
    re_path('getTextTypeInfo', views.getTextTypeInfo),
]