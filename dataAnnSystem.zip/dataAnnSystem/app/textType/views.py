from django.shortcuts import render, redirect
from .models import TextTypeInfo
import datetime
import mongoengine
import json
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
from globalTool import pageTools
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数

def getUserTextType(request):
    pageCount = 5

    userID = request.session.get("userID", None)
    textTypes = TextTypeInfo.objects.filter(userID = userID)
    URL = "textType/userTextTypes.html"
    typesList = []
    for i in range(textTypes.count()):
        typesList.append(textTypes[i])

    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(typesList, pageCount)

    try:
        pageTypesList = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageTypesList = paginator.page(1)
    except EmptyPage:
        pageTypesList = paginator.page(paginator.num_pages)

    typeList = pageTypesList.object_list
    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围
    args = {"textTypes" : typeList,'paginator': paginator,
            "pageTypesList":pageTypesList,"pageRange":pageRange}

    return render(request, URL, args)

def userInsertTextType(request):
    return render(request, "textType/addTextType.html")

def addTextType(request):
    typeName = request.POST.get('typeName')
    userID = request.session.get("userID", None)
    typeNum = TextTypeInfo.objects.filter(name = typeName, userID = userID, ifDel = 0).count()
    msg = ""
    URL = ""
    if typeNum < 1:
        TextTypeInfo.objects.create(name = typeName, userID = userID, ifDel = 0)
        msg = "alert('添加成功');"
        URL = "global/transfer.html"
    else:
        msg = "alert('添加失败，库中已有此标签');"
        URL = "global/transfer.html"
    return render(request, URL, {"msg":msg})

def getTextTypeInfo(request):
    textTypeID = request.GET.get("tpID");
    URL = "textType/editorTextType.html"
    textType = TextTypeInfo.objects.get(id=textTypeID)
    return render(request, URL, {"textType":textType})

def editorTextType(request):
    textTypeID = request.POST.get("tpID");
    newName = request.POST.get("tpName")
    print("textTypeID = " + textTypeID)
    userID = request.session.get("userID",None)
    typeNum = TextTypeInfo.objects.filter(name=newName, userID=userID, ifDel=0).count()
    msg = ""
    if typeNum>0:
        msg  ="alert('修改失败，与原数据一致');parent.$('.tabCloseCurrent').click();"
    else:
        TextTypeInfo.objects.filter(id=textTypeID).update(name=newName)
        msg = "alert('修改成功'); parent.$('.tabCloseCurrent').click();"

    #return redirect(URL,{"msg":msg})
    return render(request, "global/transfer.html", {"msg":msg})






