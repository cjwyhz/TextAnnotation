from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'task'
urlpatterns = [
    #path('index', views.get_home),
    re_path('accountGetAllTask', views.accountGetAllTask),
]