from django.db import models
import mongoengine

# Create your models here.

class TaskInfo(mongoengine.Document):
	fileID = mongoengine.StringField(verbose_name='文件ID', default="")
	applyDate = mongoengine.StringField(verbose_name='申请时间', max_length=20, default='')
	accountID = mongoengine.StringField(verbose_name='领取者信息', default="")
	userID = mongoengine.StringField(verbose_name='发布者信息', default="")
	finishStatus = mongoengine.IntField(verbose_name="是否完成", default=0)
	finishDate = mongoengine.StringField(verbose_name='完成时间', max_length=10, default='')
	ifDel = mongoengine.IntField(verbose_name='是否删除', default=0)
	
	class Meta:
		verbose_name = '人物基本信息'
		verbose_name_plural = verbose_name
		db_table = 'tasks'
	
	def __str__(self):
		return self.accountID