from django.apps import AppConfig


class TaskConfig(AppConfig):
    name = 'task'
    verbose_name = '任务信息'