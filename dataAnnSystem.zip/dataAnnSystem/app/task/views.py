from django.shortcuts import render, redirect
from .models import TaskInfo
from myFile.models import MyFileInfo
from section.models import SectionInfo
from account.models import AccountInfo
from user.models import UserInfo
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
from globalTool import pageTools
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数

def accountGetAllTask(request):
    pageCount = 5
    accountID = request.session.get("accountID", None)
    tasks = TaskInfo.objects.filter(accountID = accountID).order_by("-applyDate")
    tasksList = []
    for i in range(tasks.count()):
        tasksList.append(tasks[i])

    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(tasksList, pageCount)

    try:
        pageTasks = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageTasks = paginator.page(1)
    except EmptyPage:
        pageTasks = paginator.page(paginator.num_pages)

    taskList = pageTasks.object_list
    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围
    tasksInfo = []
    args = []
    for i in range(len(taskList)):
        arg = []
        tasksInfo.append(taskList[i])
        fileID = taskList[i].fileID
        userID = taskList[i].userID
        fileInfo = MyFileInfo.objects.get(id = fileID)
        sectionID = str(SectionInfo.objects.get(id = fileInfo.secID).id)
        userInfo = UserInfo.objects.get(id = userID)
        sectionInfo = SectionInfo.objects.get(id = sectionID)
        arg.append(userInfo.name)
        arg.append(sectionInfo.secName)
        arg.append(fileInfo.fileName)
        args.append(arg)
    tasksAndArgsInfo = zip(tasksInfo, args)
    context = {"tasksAndArgsInfo":tasksAndArgsInfo,"pageTasks":pageTasks,
               'paginator': paginator,'pageRange':pageRange}
    return render(request, "task/accountTasks.html", context)

