from .models import * 
import xadmin
from xadmin import views
from . import models

class BaseInfoAdmin:
	list_display = ['name', 'phone', 'mail']
	list_filter = ['name', 'phone', 'mail']
	fields = ['name', 'phone', 'mail']
	#search_fields=
	#list_per_page = 20
	
# class GlobalSettings(object):
# 	site_title = '发布者信息'
# 	site_footer = '发布者信息'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True

	
#xadmin.site.register(BaseInfo, BaseInfoAdmin)
#xadmin.site.register(views.CommAdminView, GlobalSettings)
#xadmin.site.register(views.BaseAdminView, BaseSetting)
