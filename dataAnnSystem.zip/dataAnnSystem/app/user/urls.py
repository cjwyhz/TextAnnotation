from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'user'
urlpatterns = [
    path('index', views.get_home),
    re_path('userRegister', views.userRegister),
    re_path('userLogin', views.userLogin),
    re_path('userInfo', views.userInfo),
    re_path('welcome', views.welcome),
    re_path('editorUserInfo', views.editorUserInfo),
    re_path('userLogOut', views.userLogOut),
    re_path('allUsers', views.getAllUsers),
    re_path('dataStatistic', views.dataStatistic),
    re_path('accountStatistic', views.accountStatistic),
]