from django.shortcuts import render, redirect
from .models import UserInfo
import datetime
import mongoengine
import invitation
from bson.objectid import ObjectId
import re
from myFile.models import MyFileInfo
from account.models import AccountInfo
from task.models import TaskInfo
from workFlow.models import WorkFlowInfo
from globalTool import pageTools
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数

def get_home(request):
    return render(request, "user/userLogin.html")

def userRegister(request):
    userName = request.POST.get('userName')
    pwd = request.POST.get('password')
    countNum = UserInfo.objects.filter(name=userName, password=pwd).count()
    msg = ""
    if countNum <= 0:
        phoneNum = request.POST.get('phone')
        Email = request.POST.get('mail')
        today = datetime.date.today()
        UserInfo.objects.create(name = userName, password = pwd, registerDate = str(today), phone = str(phoneNum), mail = Email, ifDel = 0)
        msg = "注册成功,请登录"
    else:
        msg = "注册失败,系统中已有您数据，请登录"

    msg = "alert('" + msg +"');"
    return render(request, "user/userLogin.html", {"msg":msg})

def userLogin(request):
    userName = request.POST.get('userName')
    pwd = request.POST.get('password')
    users = UserInfo.objects.filter(name=userName, password=pwd)
    countNum = users.count()
    request
    msg = "";
    URL = ""
    if countNum == 1:
        msg = "登录成功"
        URL = "user/index.html"
        userID = str(users[0].id)
        userName = str(users[0].name)
        request.session.flush()
        workFlows = WorkFlowInfo.objects.filter(examID=userID, status=0)  # 查找未审批工作流
        request.session['userID'] = userID
        request.session['userName'] = userName
        request.session['taskNum'] = workFlows.count()
    else:
        msg = "登录失败"
        print("登录失败")
        URL = "user/userLogin.html"
    loginMessage = "alert('" + msg +"');"
    #data = str(all).decode("unicode-escape")
    return render(request, URL, {"msg": loginMessage})
    #return redirect('polls:home')

def welcome(request):
    userID = request.session.get("userID", None)
    user = UserInfo.objects.get(id = userID)
    if user:
        URL = "user/userInfo.html"
        return render(request, URL, {"user": user})
    else:
        URL = "user/userLogin.html"
        return render(request, URL, {"msg":"alert('请重新登录')"})


def userInfo(request):
    userID = request.session.get("userID", None)
    user = UserInfo.objects.get(id = userID)
    if user:
        URL = "user/editorUserInfo.html"
        return render(request, URL, {"user": user})
    else:
        URL = "user/userLogin.html"
        return render(request, URL, {"msg":"alert('请重新登录')"})

def editorUserInfo(request):
    userID = request.session.get("userID", None)
    userName = request.POST.get('userName')
    pwd = request.POST.get('password')
    phoneNum = request.POST.get('phone')
    Email = request.POST.get('mail')
    UserInfo.objects.filter(id = userID).update(name = userName, password = pwd, phone = str(phoneNum), mail = Email, ifDel = 0)
    msg = "alert('修改成功，请重新登录')"
    URL = "user/userLogin.html"
    request.session.flush()
    return render(request, URL, {"msg": msg})

def userLogOut(request):
    URL = "user/userLogin.html"
    request.session.flush()
    msg = "alert('退出成功,感谢使用')"
    return render(request, URL, {"msg": msg})

def getAllUsers(request):#account获取所有发布任务者
    usersList = []
    users = UserInfo.objects.filter(ifDel = 0)
    for i in range(users.count()):
        usersList.append(users[i])

    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(usersList, PAGECOUNT)

    try:
        pageUsers = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageUsers = paginator.page(1)
    except EmptyPage:
        pageUsers = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)

    userList = pageUsers.object_list

    args = {"users":userList,"pageUsers":pageUsers,"paginator":paginator,"pageRange":pageRange}
    return render(request,"user/allUsers.html",args)


def dataStatistic(request):
    userID = request.session.get("userID",None)
    year = request.GET.get("year")
    if not year:
        year = str(datetime.datetime.now().year)  # 当前年份
    timeStart = year + "-"
    accountsWF = WorkFlowInfo.objects.filter(examID=userID,applyDate__startswith=timeStart).fields("accountID").distinct("accountID")#涉及到的学生

    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(accountsWF, PAGECOUNT)

    try:
        pageWfs = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageWfs = paginator.page(1)
    except EmptyPage:
        pageWfs = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围

    pageWfsList = pageWfs.object_list
    accountsList = []
    infosList = []
    for accountID in pageWfsList:
        account = AccountInfo.objects.get(id = accountID)
        accountsList.append(account)
        info = dict()
        applyWf = WorkFlowInfo.objects.filter(accountID=accountID,examID=userID,applyDate__startswith=timeStart).fields("fileID").distinct("fileID")#对应学生申请工作数
        passApplyWf = WorkFlowInfo.objects.filter(accountID=accountID, examID=userID,applyDate__startswith=timeStart,result=1).fields("fileID").distinct("fileID")  # 对应学生申请通过数
        finishedTasks = TaskInfo.objects.filter(userID=userID,accountID=accountID,finishStatus=1,finishDate__startswith=timeStart)
        info['applyNum'] = len(applyWf)#申请数
        info['passNum'] = len(passApplyWf)#通过数
        info['finishedNum'] = finishedTasks.count()#完成数
        infosList.append(info)

    accountAndInfosList = zip(accountsList, infosList)
    args = {"accountAndInfosList": accountAndInfosList, "year": year,
            "pageWfs":pageWfs,"paginator":paginator,"pageRange":pageRange}
    return render(request,"user/dataStatistic.html",args)
def accountStatistic(request):#学生个人工作统计
    accountID = request.GET.get("accountID")
    account = AccountInfo.objects.get(id=accountID)
    userID = request.session.get("userID")
    year = request.GET.get("year")
    if not year:
        year = str(datetime.datetime.now().year)#当前年份
    personalInfo = []
    totalApplyNum = 0
    totalPassNum = 0
    totalFinishedNum = 0

    for index in range(1,13):
        info = dict()
        month = str(index)
        if len(month) < 2:
            month  = "0" + month
        timeStart = year + "-" + month
        applyWf = WorkFlowInfo.objects.filter(accountID=accountID, examID=userID,
                                              applyDate__startswith=timeStart).fields("fileID").distinct("fileID")  # 对应学生申请工作数
        passApplyTask = TaskInfo.objects.filter(accountID=accountID, userID=userID,
                                                  applyDate__startswith=timeStart).fields("fileID").distinct("fileID")  # 对应学生申请通过数
        finishedTasks = TaskInfo.objects.filter(userID=userID, accountID=accountID,
                                                finishStatus=1,finishDate__startswith=timeStart).fields("fileID").distinct("fileID")
        info['month'] = str(index) + "月"
        info['applyNum'] = len(applyWf)  # 申请数
        totalApplyNum += len(applyWf)#计算年度总申请数

        info['passNum'] = len(passApplyTask)  # 通过数
        totalPassNum += len(passApplyTask)  # 计算年度总申请数

        info['finishedNum'] = len(finishedTasks)  # 完成数
        totalFinishedNum += len(finishedTasks)  # 计算年度总申请数

        personalInfo.append(info)

    totalInfo = dict()
    totalInfo['month'] = '<font size="4px" color="red">总计</font>'
    totalInfo['applyNum'] = '<font size="4px" color="red">' + str(totalApplyNum) + '</font>'
    totalInfo['passNum'] = '<font size="4px" color="red">' + str(totalPassNum) + '</font>'
    totalInfo['finishedNum'] = '<font size="4px" color="red">' + str(totalFinishedNum) + '</font>'
    personalInfo.append(totalInfo)
    context = {"personalInfo":personalInfo,"year":year,"account":account}
    return render(request,"user/personalStatistic.html",context)













