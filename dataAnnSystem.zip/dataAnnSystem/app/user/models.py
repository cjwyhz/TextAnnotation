from django.db import models
import mongoengine

# Create your models here.

class UserInfo(mongoengine.Document):
	name = mongoengine.StringField(verbose_name='姓名', max_length=20, default='')
	password = mongoengine.StringField(verbose_name='密码', max_length=100, default='')
	registerDate = mongoengine.StringField(verbose_name='注册时间', max_length=20, default='')
	phone = mongoengine.StringField(verbose_name='手机号', max_length=12, default='')
	mail = mongoengine.StringField(verbose_name='邮箱', max_length=20, default='')
	ifDel = mongoengine.IntField(verbose_name='是否删除', default=1)
	
	class Meta:
		verbose_name = '发布者基本信息'
		verbose_name_plural = verbose_name
		db_table = "users"
	
	def __str__(self):
		return "'" + str(self.id) + "':'" + self.name +"'"