from .models import * 
import xadmin
from xadmin import views
from . import models

class MyFileInfoAdmin:
	list_display = ['fileName', 'publishDate']
	list_filter = ['fileName', 'publishDate']
	fields = ['fileName', 'publishDate']
	#search_fields=
	#list_per_page = 20
	
# class GlobalSettings(object):
# 	site_title = '文件信息'
# 	site_footer = '已发布信息'
# 	menu_style = 'accordion'
#
# class BaseSetting(object):
# 	enable_themes = True
# 	use_bootswatch = True

	
#xadmin.site.register(BaseInfo, BaseInfoAdmin)
#xadmin.site.register(views.CommAdminView, GlobalSettings)
#xadmin.site.register(views.BaseAdminView, BaseSetting)
