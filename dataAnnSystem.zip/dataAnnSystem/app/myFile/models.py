from django.db import models
import mongoengine

# Create your models here.

class MyFileInfo(mongoengine.Document):
	userID = mongoengine.StringField(verbose_name='发布者信息', default=-1)
	fileName = mongoengine.StringField(verbose_name='文件名', max_length=50, default='')
	finishedStatus = mongoengine.IntField(verbose_name='是否完成', default=0)
	secID = mongoengine.StringField(verbose_name='所属章节', default=-1)
	taskAccountID = mongoengine.StringField(verbose_name='完成者', default=-1)
	publishDate = mongoengine.StringField(verbose_name='发布时间', max_length=50, default='')
	finishedDate = mongoengine.StringField(verbose_name='完成时间', max_length=50, default='')
	class Meta:
		verbose_name = '文件基本信息'
		verbose_name_plural = verbose_name
		db_table = 'files'
	
	def __str__(self):
		return self.fileName
	