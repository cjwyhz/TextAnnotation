from django.http import FileResponse
from django.shortcuts import render, redirect, HttpResponse
from .models import MyFileInfo
from section.models import SectionInfo
from task.models import TaskInfo
from workFlow.models import WorkFlowInfo
from account.models import AccountInfo
import datetime
import mongoengine
from wsgiref.util import FileWrapper
import os
import time
import json
from . import tools
import xlrd
from ast import literal_eval
from xlrd import open_workbook
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from django.db.models.aggregates import Count
from shutil import rmtree
import tempfile
from globalTool import pageTools
from globalTool import constantVariable
PAGECOUNT = constantVariable.PAGECOUNT#每页展示数据条目
PAGEBTNCOUNT = constantVariable.PAGEBTNCOUNT#每页展示分页按钮个数
FILEDIR = constantVariable.FILEDIR#文档基础路径
def upload(request):
    secID = request.GET.get("secID")
    request.session['uploadSecID'] = secID
    print("secID = " + secID)
    return render(request, "myFile/filesUpload.html")

def filesUpload(request):
    userID = request.session.get("userID", None)
    secID = request.session.get("uploadSecID", None)
    userFileDir = FILEDIR + "\\" + userID + "\\" + secID
    if os.path.exists(userFileDir):
        print("路径已经存在")
    else:
        os.makedirs(userFileDir)

    if request.method == 'GET':
        return render(request, "myFile/filesUpload.html")
    elif request.is_ajax():
        # 根据input框的name属性值取到文件对象

        fileName = ""
        finishedStatus = 0
        taskAccountID = "-1"
        publishDate = str(datetime.date.today())
        finishedDate = "-"

        files = request.FILES.getlist('file')
        for file in files:
            # 获取文件名，文件对象的__str__属性返回的是文件名
            file_name = str(file)

            if MyFileInfo.objects.filter(userID = userID, fileName = file_name, secID = secID).count() < 1:
                with open(os.path.join(userFileDir, file_name), 'wb') as f:
                    # 分块写入，防止大文件卡死
                    for chunk in file.chunks(chunk_size=2014):
                        f.write(chunk)
                fileName = file_name
                MyFileInfo.objects.create(userID = userID, fileName = fileName, finishedStatus = finishedStatus,
                                          secID = secID, taskAccountID = taskAccountID, publishDate = publishDate,
                                          finishedDate = finishedDate)

                oldNum = SectionInfo.objects.get(id=secID).filesNum
                newFilesNum = oldNum + 1
                SectionInfo.objects.filter(id=secID).update(filesNum = newFilesNum)

        return HttpResponse(json.dumps({"status": 1}))


def filesDown(request):
    fileID = request.GET.get("fileID")
    secID = request.GET.get("secID")
    myFile = MyFileInfo.objects.get(id=fileID)
    fileName = ""
    path = ""
    response = dict()
    if myFile:
        userID = myFile.userID
        secID = myFile.secID
        fileName = myFile.fileName
        path = FILEDIR + "\\" + userID + "\\" + secID
        filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName
        if os.path.exists(filePath):#判断文件是否存在
            response = tools.downloadFile(path,fileName)
    return response

def getFilesBySection(request):
    upSecID = request.session.get("uploadSecID", None)
    if upSecID:
        del request.session['uploadSecID']
    #del request.session["uploadSecID"]
    userID = request.session.get("userID", None)
    secID = request.GET.get("secID")
    files = MyFileInfo.objects.filter(userID = userID, secID = secID)

    filesList = []
    for i in range(files.count()):
        filesList.append(files[i])
    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(filesList, PAGECOUNT)

    try:
        pageFiles = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageFiles = paginator.page(1)
    except EmptyPage:
        pageFiles = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围

    pageFilesList = pageFiles.object_list

    filesInfo = []
    accountNames = []
    for i in range(len(pageFilesList)):
        filesInfo.append(pageFilesList[i])
        accountID = pageFilesList[i].taskAccountID

        if str(accountID) != "-1":
            accountInfo = AccountInfo.objects.get(id=accountID)
            accountNames.append(accountInfo.name)
        else:
            accountNames.append("暂无")
    filesInfoAndargs = zip(filesInfo, accountNames)
    args = {"filesInfoAndargs" : filesInfoAndargs, "secID":secID,"pageFiles":pageFiles,
            'paginator': paginator,"pageRange":pageRange}
    return render(request, "myFile/sectionFiles.html", args)

def accountGetFilesBySection(request):#学生获取可以领取的任务列表
    userID = request.GET.get("userID", None)
    secID = request.GET.get("secID")
    msg = request.GET.get("msg")
    if msg:
        print("msg = " + str(msg))
    files = MyFileInfo.objects.filter(userID = userID, secID = secID)
    filesList = []
    for i in range(files.count()):
        filesList.append(files[i])
    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(filesList, PAGECOUNT)

    try:
        pageFiles = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageFiles = paginator.page(1)
    except EmptyPage:
        pageFiles = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围

    pageFilesList = pageFiles.object_list
    filesInfo = []
    userWorkStaus = []
    accountWorkStatus = []
    for i in range(len(pageFilesList)):
        filesInfo.append(pageFilesList[i])
        fileID = str(pageFilesList[i].id)
        tasks = TaskInfo.objects.filter(fileID = fileID,ifDel = 0)
        workFlows = WorkFlowInfo.objects.filter(fileID = fileID, status = 0)
        if tasks.count()>0 or workFlows.count()>0:
            btnInfo = "0"
            accountWorkStatus.append(btnInfo)
        else:
            btnInfo = "1"
            accountWorkStatus.append(btnInfo)

    filesAndStatus = zip(filesInfo, accountWorkStatus)

    args = {"filesAndStatus" : filesAndStatus, "secID":secID,"userID":userID,"pageFiles":pageFiles,
            "paginator":paginator,"pageRange":pageRange}
    if not msg:
        return render(request, "myFile/accountShowSectionFiles.html",args)
    else:
        args['msg'] = msg
        return render(request, "myFile/accountShowSectionFiles.html", args)

def deleteFile(request):
    secID = request.GET.get("secID")
    fileID = request.GET.get("fileID")
    myFile = MyFileInfo.objects.get(id = fileID)
    if myFile:
        userID = myFile.userID
        secID = myFile.secID
        fileName = myFile.fileName
        filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName
        if os.path.exists(filePath):
            os.remove(filePath)

        myFile.delete()
        oldNum = SectionInfo.objects.get(id=secID).filesNum
        newFilesNum = oldNum - 1
        SectionInfo.objects.filter(id=secID).update(filesNum=newFilesNum)

    return redirect("/myFile/getFilesBySection?secID=" + secID)

def readExcel(request):
    fileID = request.GET.get("fileID");
    myFile = MyFileInfo.objects.get(id = fileID)
    userID = myFile.userID
    fileName = myFile.fileName
    secID = myFile.secID
    filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName
    excel = xlrd.open_workbook(filePath)
     # 得到第一张表单
    sheet1 = excel.sheets()[0]
     # 找到有几列几列
    nrows = sheet1.nrows  # 行数
    ncols = sheet1.ncols  # 列数

    totalArray = []
    title = []
    # 标题
    for i in range(0, ncols):
        title.append(sheet1.cell(0, i).value);

    # 数据
    for rowindex in range(1, nrows):
        dic = {}
        for colindex in range(0, ncols):
            s = sheet1.cell(rowindex, colindex).value
            dic[title[colindex]] = s
        totalArray.append(dic);


    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(totalArray, PAGECOUNT)

    try:
        pageContext = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageContext = paginator.page(1)
    except EmptyPage:
        pageContext = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围
    pageContextList = pageContext.object_list





    # string = json.dumps(totalArray, ensure_ascii=False)
    # list_string = literal_eval(string)#将字符串列表转换为列表对象
    # for i in range(len(list_string)):
    #     print(list_string[i])
    args = {"models":pageContextList, "title":title,"pageRange":pageRange,
            "fileID":fileID,"pageContext":pageContext,"paginator":paginator}
    return render(request,"myFile/fileContent.html",args)



def showExcelContext(request):
    fileID = request.GET.get("fileID");
    locationURL = request.GET.get("url")
    myFile = MyFileInfo.objects.get(id = fileID)
    userID = myFile.userID
    fileName = myFile.fileName
    secID = myFile.secID
    filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName
    excel = xlrd.open_workbook(filePath)
     # 得到第一张表单
    sheet1 = excel.sheets()[0]
     # 找到有几列几列
    nrows = sheet1.nrows  # 行数
    ncols = sheet1.ncols  # 列数

    totalArray = []
    title = []
    # 标题
    for i in range(0, ncols):
        title.append(sheet1.cell(0, i).value);

    # 数据
    for rowindex in range(1, nrows):
        dic = {}
        for colindex in range(0, ncols):
            s = sheet1.cell(rowindex, colindex).value
            dic[title[colindex]] = s
        totalArray.append(dic);
    try:
        current_page = int(request.POST.get('pageNum'))
    except Exception as e:
        current_page = 1
    paginator = Paginator(totalArray, PAGECOUNT)

    try:
        pageContext = paginator.page(current_page)
        # paginator.page_range
    except PageNotAnInteger:
        pageContext = paginator.page(1)
    except EmptyPage:
        pageContext = paginator.page(paginator.num_pages)

    pageRange = pageTools.getPageBtnRange(paginator, current_page, PAGEBTNCOUNT)  # 获取按钮显示范围
    pageContextList = pageContext.object_list


    # string = json.dumps(totalArray, ensure_ascii=False)
    # list_string = literal_eval(string)#将字符串列表转换为列表对象
    # for i in range(len(list_string)):
    #     print(list_string[i])
    args = {"models": pageContextList, "title": title, "pageRange": pageRange,
            "fileID": fileID, "pageContext": pageContext, "paginator": paginator}
    return render(request,str(locationURL),args)
# Create your views here.

def downloadSectionFiles(request):#下载整章文档
    secID = request.GET.get("secID")
    section = SectionInfo.objects.get(id=secID)
    temp = tempfile.TemporaryFile()
    userID = request.session.get("userID", None)
    path = FILEDIR + "\\" + userID + "\\" + secID
    secName = section.secName
    fileName = "第" + str(section.secIndex) + "章-" + secName + ".zip"
    #zipFilePath = userFileDir +  "\\" + fileName
    zipFile = tools.zipDir(path,temp)
    response = tools.tempFileDownload(temp,fileName)
    return response

def filesBathDownload(request):#批量下载
    temp = tempfile.TemporaryFile()
    filesID = request.POST.getlist('filesID')
    secID = request.POST.get("secID")
    section = SectionInfo.objects.get(id=secID)
    userID = str(section.userID)
    response = dict()
    path = FILEDIR + "\\" + userID + "\\" + secID
    if len(filesID) < 2:
        fileID = filesID[0]
        file = MyFileInfo.objects.get(id=fileID)
        fileName = file.fileName
        filePath = FILEDIR + "\\" + userID + "\\" + secID + "\\" + fileName
        if os.path.exists(filePath):  # 判断文件是否存在
            response = tools.downloadFile(path, fileName)
    else:
        filesName = []
        for fileID in filesID:
            file = MyFileInfo.objects.get(id=fileID)
            filesName.append(file.fileName)
        tools.zipTargetFiles(filesName,path,temp)
        zipFileName = "第" + str(section.secIndex) + "章-" + str(section.secName) + ".zip"
        response = tools.tempFileDownload(temp, zipFileName)

    return response







