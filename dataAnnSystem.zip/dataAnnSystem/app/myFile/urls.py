from django.urls import path, re_path
from . import views
from django.conf.urls import url

app_name = 'myFile'
urlpatterns = [
    #path('index', views.get_home),
    re_path('upload', views.upload),
    re_path('filesUpload', views.filesUpload),
    re_path('getFilesBySection', views.getFilesBySection),
    re_path('accountGetFilesBySection', views.accountGetFilesBySection),
    re_path('deleteFile', views.deleteFile),
    re_path('readExcel', views.readExcel),
    re_path('showExcelContext', views.showExcelContext),
    re_path('filesDown', views.filesDown),
    re_path('filesBathDownload', views.filesBathDownload),
    re_path('downloadSectionFiles', views.downloadSectionFiles),
]