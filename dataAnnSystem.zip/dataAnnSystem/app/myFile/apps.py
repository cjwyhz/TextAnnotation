from django.apps import AppConfig


class FileConfig(AppConfig):
    name = 'myFile'
    verbose_name = '文件信息'