import os
import zipfile
from django.http import FileResponse
from django.utils.http import urlquote
from django.shortcuts import render, redirect, HttpResponse
from wsgiref.util import FileWrapper

def zipDir(dirpath, outFullName):
    """
    压缩指定文件夹
    :param dirpath: 目标文件夹路径
    :param outFullName: 压缩文件保存路径+xxxx.zip
    :return: 无
    """
    zip = zipfile.ZipFile(outFullName, "w", zipfile.ZIP_DEFLATED)
    for path, dirnames, filenames in os.walk(dirpath):
        # 去掉目标跟路径，只对目标文件夹下边的文件及文件夹进行压缩
        fpath = path.replace(dirpath, '')
        for filename in filenames:
            zip.write(os.path.join(path, filename), os.path.join(fpath, filename))
    zip.close()
    return zip

def zipTargetFiles(filesName,path,temp):
    zip = zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED)
    for fileName in filesName:
        zip.write(os.path.join(path,fileName), os.path.join('', fileName))
    zip.close()



def downloadFile(path,fileName):
    fr = open(os.path.join(path, fileName), 'rb')
    response = FileResponse(fr)
    response['content_type'] = "application/octet-stream"
    chineseFileName = 'attachment; filename="%s"' % fileName
    response['Content-Disposition'] = chineseFileName.encode('utf-8', 'ISO-8859-1')
    return response

def tempFileDownload(temp,fileName):
    tell = temp.tell()
    temp.seek(0)
    wrapper = FileWrapper(temp)  # 这个狗逼函数会将文件关闭，导致temp的调用全部报错，在调用该函数之前用临时变量将该函数的属性保存
    response = HttpResponse(wrapper, content_type='application/zip')
    chineseFileName = 'attachment; filename="%s"' % fileName
    response['Content-Disposition'] = chineseFileName.encode('utf-8', 'ISO-8859-1')
    response['Content-Length'] = tell
    return response